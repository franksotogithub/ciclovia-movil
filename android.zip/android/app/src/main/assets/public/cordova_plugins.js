
  cordova.define('cordova/plugin_list', function(require, exports, module) {
    module.exports = [
      {
          "id": "cordova-plugin-background-geolocation.BackgroundGeolocation",
          "file": "plugins/cordova-plugin-background-geolocation/www/BackgroundGeolocation.js",
          "pluginId": "cordova-plugin-background-geolocation",
        "clobbers": [
          "BackgroundGeolocation"
        ]
        },
      {
          "id": "cordova-plugin-background-geolocation.radio",
          "file": "plugins/cordova-plugin-background-geolocation/www/radio.js",
          "pluginId": "cordova-plugin-background-geolocation"
        }
    ];
    module.exports.metadata =
    // TOP OF METADATA
    {
      "cordova-plugin-background-geolocation": "3.1.0"
    };
    // BOTTOM OF METADATA
    });
    