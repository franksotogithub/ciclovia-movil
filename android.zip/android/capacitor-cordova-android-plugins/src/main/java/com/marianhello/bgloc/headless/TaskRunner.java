package com.marianhello.bgloc.headless;

public interface TaskRunner {
    void runTask(Task task);
}
